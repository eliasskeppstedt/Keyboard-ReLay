#ifndef _MAIN_
#define _MAIN_

#include <stdlib.h>

#include "storeData.h"
#include "data.h"
#include "relayEventHandler.h"

int main();
void cleanup();

#endif // _MAIN_