#ifndef _RELAYEVENTHANDLER_
#define _RELAYEVENTHANDLER_

#include "os/interface.h"

#define RL_ESCAPE 0x30

int start(MyReLay* myReLay);

#endif // _RELAYEVENTHANDLER_