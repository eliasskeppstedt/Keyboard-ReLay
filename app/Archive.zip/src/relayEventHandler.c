#include "../header/relayEventHandler.h"

static int activeEventFlags = 0;

int start(MyReLay* myReLay)
{
    initRunLoop(myReLay);
    return 0;
}

// defined in interfaces.h
void eventCallBack(MyReLay* myReLay, RLEvent* incomingEvent)
{
    if (incomingEvent->code == RL_ESCAPE) 
    {
        closeRunLoop(NULL); 
        return;
    }
    RLEvent* headEventPreview = NULL;
    RLEvent* outgoingEvent = NULL;

    if (incomingEvent->code == NO_VALUE) goto wasTimeTriggered;

    if (incomingEvent->keyDown)
    {
        if (KEY_INFO(myReLay, incomingEvent)->codeOnHold) 
        {
            incomingEvent->state = PENDING;
            //startOnHoldTimer(&incomingEvent->timer);
        }
        else 
        {
            int codeOnPress = KEY_INFO(myReLay, incomingEvent)->codeOnPress;
            if (codeOnPress != NO_VALUE)
            {
                incomingEvent->code = codeOnPress;
            }
            incomingEvent->state = SEND;
        }
    }
    else
    {
        incomingEvent->state = SEND; // keyUp-event behöver aldrig vänta på ett event utan ska postas så fort det är möjligt
    }
    enqueue(incomingEvent, &myReLay->eventQueue);

    wasTimeTriggered:
    
    headEventPreview = getEvent(&myReLay->eventQueue, HEAD); 
    outgoingEvent = NULL;

    if (headEventPreview->state != PENDING) goto notPending;

    uint64_t timeSincePressed = getTimeStamp() - headEventPreview->timeStampOnPress;
    if (timeSincePressed > ON_HOLD_THRESHOLD)
    {
        headEventPreview->code = KEY_INFO(myReLay, headEventPreview)->codeOnHold;
        headEventPreview->state = SEND;
    }
    else if (headEventPreview->code == KEY_INFO(myReLay, incomingEvent)->code)
    {
        if (KEY_INFO(myReLay, incomingEvent)->codeOnPress != NO_VALUE)
        {
            headEventPreview->code = KEY_INFO(myReLay, incomingEvent)->codeOnPress;
        }
        headEventPreview->state = SEND;
    }

    notPending:

    if (headEventPreview->isModifier && headEventPreview->state == SEND)
    {
        if (headEventPreview->keyDown)
        {
            activeEventFlags |= headEventPreview->flagMask;
        }
        else
        {
            activeEventFlags &= headEventPreview->flagMask;
        }
    }
    
    while (headEventPreview->state == SEND)
    {
        headEventPreview->flagMask = activeEventFlags;
        outgoingEvent = dequeue(&myReLay->eventQueue);
        postEvent(outgoingEvent, myReLay->rlToOS);
        free(outgoingEvent);
    }
}

uint64_t getTimeStamp()
{
    struct timeval timeStamp;
    gettimeofday(&timeStamp, NULL);
    return (uint64_t)timeStamp.tv_sec * 1000000ULL + (uint64_t)timeStamp.tv_usec; // ULL - unsigned long long
}

void printRLEvent(RLEvent* rlEvent)
{
    printf("  rlEvent {\n");
    printf("    code: %d\n", rlEvent->code);
    printf("    flagMask: %llu\n", rlEvent->flagMask);
    printf("    timeStampOnPress: %llu\n", rlEvent->timeStampOnPress);
    char* state = "[state]";
    if (rlEvent->state == NORMAL) { state = "NORMAL"; }
    printf("    state: %s\n", state);
    printf("    isModifier: %s\n", rlEvent->isModifier ? "true" : "false");
    printf("    keyDown: %s\n", rlEvent->keyDown ? "true" : "false");
    printf("  }\n");
}